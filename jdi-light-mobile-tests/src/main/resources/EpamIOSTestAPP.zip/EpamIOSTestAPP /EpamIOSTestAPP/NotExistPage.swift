//
//  NotExistPageView.swift
//  EpamIOSTestAPP
//
//  Created by Roman Morozov2 on 12.11.2020.
//

import SwiftUI

struct NotExistPage: View {
    @EnvironmentObject var viewRouter: ViewRouter
    var body: some View {
        Text("This page is not made").font(Font.largeTitle)
        Button(action: {
            withAnimation {
                viewRouter.currentPage = .MainPage
            }
        }) {
            BackButtonContent()
        }
    }
}

struct NotExistPage_Previews: PreviewProvider {
    static var previews: some View {
        NotExistPage()
    }
}

