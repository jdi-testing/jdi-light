//
//  AlertDialogPage.swift
//  EpamIOSTestAPP
//
//  Created by Roman Morozov2 on 16.11.2020.
//

import SwiftUI

struct AlertDialogPage: View {
    
    @EnvironmentObject var viewRouter: ViewRouter
    @State private var showingAlert = false
    
    var body: some View {
        Button(action: {
                    self.showingAlert = true
                }) {
                 Text("Show Alert").foregroundColor(.white)
                 .frame(width: 200, height: 50)
                 .background(Color.green)
                 .cornerRadius(15)
                 .padding(.top, 80)
                }
                .alert(isPresented: $showingAlert) {
                    Alert(title: Text("Important message"), message: Text("It is Alert!"), dismissButton: .default(Text("Got it!")))
                }

        Button(action: {
            withAnimation {
                viewRouter.currentPage = .MainPage
            }
        }) {
            BackButtonContent()
        }
    }
}

struct AlertDialogPage_Previews: PreviewProvider {
    static var previews: some View {
        AlertDialogPage()
    }
}
