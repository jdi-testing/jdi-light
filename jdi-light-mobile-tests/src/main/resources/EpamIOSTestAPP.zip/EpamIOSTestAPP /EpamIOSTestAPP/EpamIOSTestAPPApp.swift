//
//  EpamIOSTestAPPApp.swift
//  EpamIOSTestAPP
//
//  Created by Roman Morozov2 on 11.11.2020.
//

import SwiftUI

@main
struct EpamIOSTestAPPApp: App {
    @StateObject var viewRouter = ViewRouter()
    var body: some Scene {
        WindowGroup {
            MotherView().environmentObject(viewRouter)
        }
    }
}
