//
//  ContentView.swift
//  EpamIOSTestAPP
//
//  Created by Roman Morozov2 on 11.11.2020.
//

import SwiftUI

struct MotherView: View {
    @EnvironmentObject var viewRouter: ViewRouter
      
      var body: some View {
          switch viewRouter.currentPage {
          case .MainPage:
            MainPage()
          case .NotExistPage:
            NotExistPage()
          case .SliderPage:
            SliderPage()
          case .ActionSheetPage:
            ActionSheetPage()
          case .ContextMenuPage:
            ContextMenuPage()
          case .ToggleSwitchPage:
            ToggleSwitchPage()
          case .AlertDialogPage:
            AlertDialogPage()
          case .TabViewPage:
            TabViewPage()
          case .TextFieldPage:
            TextFieldPage()
          case .SegmentedControlPage:
            SegmentedControlPage()
          case .StepperPage:
            StepperPage()
          case .DatePickerPage:
            DatePickerPage()
                  .transition(.scale)
          }
      }
  }

  struct MotherView_Previews: PreviewProvider {
      static var previews: some View {
          MotherView().environmentObject(ViewRouter())
      }
  }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
//    let disciplines = ["Button", "DatePicker", "Checkbox", "ActionSheet", "AlertDialog",
//    "ContextMenu","DialogAction", "Scrollbar","SegmentedControl","SlidingSegmentedControl","Slider","Switch", "TabBar", "Stepper"]
//    var body: some View {
//        NavigationView {
//               List(disciplines, id: \.self) { discipline in
//              NavigationLink(destination: DetailView(discipline: discipline)) {
//                  Text(discipline).accessibility(identifier: discipline)
//              }
//               }.navigationBarTitle("JDI Test App", displayMode: .inline)
//
//        }
//    }
//}
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
//
//struct DetailView: View {
//
//  let discipline: String
//  var body: some View {
//        NavigationView {
//                        if(discipline == "Button") {
//                            NavigationLink(destination: ButtonView()) {
//                                ButtonView()
//                            }
//                        } else if(discipline == "DatePicker") {
//                            NavigationLink (destination: Text("DatePicker")){
//                                DatePickerView()
//                            }.navigationBarTitle("DatePicker")
//                        } else {
//                            NavigationLink(destination: ButtonView()) {
//                                Text(discipline)
//                            }
//                        }
//                }
//           }
//  }

