//
//  SegmentedControlPage.swift
//  EpamIOSTestAPP
//
//  Created by Roman Morozov2 on 16.11.2020.
//

import SwiftUI

struct SegmentedControlPage: View {
    @State private var selectorIndex = 0
    @EnvironmentObject var viewRouter: ViewRouter
    @State private var numbers = ["One","Two","Three"]
      
        var body: some View {
            VStack {
                Picker("Numbers", selection: $selectorIndex) {
                    ForEach(0 ..< numbers.count) { index in
                        Text(self.numbers[index]).tag(index)
                    }
                }.accessibility(identifier: "SegmentedControld")                .pickerStyle(SegmentedPickerStyle())
        
                Text("Selected value is: \(numbers[selectorIndex])").padding()
            }
            Text(" ")
            Button(action: {
                withAnimation {
                    viewRouter.currentPage = .MainPage
                }
            }) {
                BackButtonContent()
            }
        }
}

struct SegmentedControlPage_Previews: PreviewProvider {
    static var previews: some View {
        SegmentedControlPage()
    }
}
