//
//  ContentViewB.swift
//  EpamIOSTestAPP
//
//  Created by Roman Morozov2 on 12.11.2020.
//

import SwiftUI

struct DatePickerPage: View {
    
    @EnvironmentObject var viewRouter: ViewRouter
    @State private var date = Date()
    var body: some View {
            Text("DatePicker").padding(.top, 10 ).font(Font.largeTitle)
        
        VStack {
             DatePicker("Enter your birthday", selection: $date)
            .datePickerStyle(GraphicalDatePickerStyle())
            .frame(maxHeight: 400)
        }
        
        Text("Date is \(date)").padding(.all, 20)
            Button(action: {
                withAnimation {
                    viewRouter.currentPage = .MainPage
                }
            }) {
                BackButtonContent()
            }
    }
 }


struct ContentViewB_Previews: PreviewProvider {
    static var previews: some View {
        DatePickerPage().environmentObject(ViewRouter())
    }
}


struct BackButtonContent : View {
    var body: some View {
        return Text("Back to menu")
            .foregroundColor(.white)
            .frame(width: 200, height: 50)
            .background(Color.blue)
            .cornerRadius(15)
            .padding(.top, 50)
    }
}
