//
//  SliderPage.swift
//  EpamIOSTestAPP
//
//  Created by Roman Morozov2 on 12.11.2020.
//

import SwiftUI

struct SliderPage: View {
    @State var sliderValue: Double = 0
    @EnvironmentObject var viewRouter: ViewRouter
    var body: some View {
        VStack {
            Text("Slider").padding(.top, 10 ).font(Font.largeTitle)
            Slider(value: $sliderValue, in: 0...20).accessibility(identifier: "SliderId")
                   Text("Current slider value: \(sliderValue, specifier: "%.2f")")
               }.padding()
        
            Button(action: {
                withAnimation {
                    viewRouter.currentPage = .MainPage
                }
            }) {
                BackButtonContent()
            }
    }
}

struct SliderPage_Previews: PreviewProvider {
    static var previews: some View {
        SliderPage()
    }
}
