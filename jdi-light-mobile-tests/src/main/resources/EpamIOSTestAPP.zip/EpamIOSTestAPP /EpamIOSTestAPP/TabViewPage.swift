//
//  TabViewPage.swift
//  EpamIOSTestAPP
//
//  Created by Roman Morozov2 on 16.11.2020.
//

import SwiftUI

struct TabViewPage: View {
    @EnvironmentObject var viewRouter: ViewRouter
    var body: some View {
       
        TabView {
                    Text("First View")
                        .tabItem {
                            Image(systemName: "1.circle")
                            Text("First")
                        }.accessibility(identifier: "TabItemFirstId").tag(0)
                    Text("Second View")
                        .tabItem {
                            Image(systemName: "2.circle")
                            Text("Second")
                        }.accessibility(identifier: "TabItemSecondId").tag(1)
                     Button(action: {
                       withAnimation {
                    viewRouter.currentPage = .MainPage
                             }
                            }) {
                      BackButtonContent()
                             }
                       .tabItem {
                           Image(systemName: "3.circle")
                        Text("Exit")
                       }.accessibility(identifier: "TabItemExitId").tag(2)
                     }.accessibility(identifier: "TabId")
    }
}

struct TabViewPage_Previews: PreviewProvider {
    static var previews: some View {
        TabViewPage()
    }
}
