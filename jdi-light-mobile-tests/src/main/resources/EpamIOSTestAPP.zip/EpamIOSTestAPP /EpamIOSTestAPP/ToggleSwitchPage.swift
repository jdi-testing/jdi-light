//
//  ToggleSwitchPage.swift
//  EpamIOSTestAPP
//
//  Created by Roman Morozov2 on 16.11.2020.
//

import SwiftUI

struct ToggleSwitchPage: View {
    @EnvironmentObject var viewRouter: ViewRouter
    @State private var showMessage = false
    @State var isOn: Bool = false
    var body: some View {
        VStack {
            Text("Move to switch")
              Toggle(isOn: $showMessage) {
                  Text("Move the switch")
              }.accessibility(identifier: "ToggleId").labelsHidden()
                 Text(" ")
                 Text(" ")
                 Text(" ")
                  if showMessage {
                      Text("The switch is on!")
                  } else {
                    Text("The switch is off!")
                  }
                Text(" ")
                Text(" ")
                Text(" ")
            Button(action: {
                withAnimation {
                    viewRouter.currentPage = .MainPage
                }
            }) {
                BackButtonContent()
            }
        }.padding(.all, 50)
}

struct ToggleSwitchPage_Previews: PreviewProvider {
    static var previews: some View {
        ToggleSwitchPage()
    }
 }
}
