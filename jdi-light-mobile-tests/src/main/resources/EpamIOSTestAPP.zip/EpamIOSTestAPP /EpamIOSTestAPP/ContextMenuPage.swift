//
//  ContextMenuPage.swift
//  EpamIOSTestAPP
//
//  Created by Roman Morozov2 on 13.11.2020.
//

import SwiftUI

struct ContextMenuPage: View {
    @EnvironmentObject var viewRouter: ViewRouter
    @State private var choose: String  = "-"
    var body: some View {
        VStack {
            Text("Selected value is:").padding(.all, 20)
            Text("\(choose)").padding(.all, 20).font(Font.largeTitle)
            Text(" ")
            Text(" ")
            Text(" ")
            
            Text("Long press to open the menu")
             .foregroundColor(.green)
             .padding(.top, 50)
             .contextMenu {
                       Button(action: {
                        choose = "one"
                       }) {
                           Text("one")
                       }

                       Button(action: {
                        choose = "two"
                       }) {
                           Text("two")
                       }

                       Button(action: {
                        choose = "three"
                       }) {
                           Text("three")
                       }
                   }
           }
        
            Button(action: {
                withAnimation {
                    viewRouter.currentPage = .MainPage
                }
            }) {
                BackButtonContent()
            }
    }
    }


struct ContextMenuPage_Previews: PreviewProvider {
    static var previews: some View {
        ContextMenuPage()
    }
}
