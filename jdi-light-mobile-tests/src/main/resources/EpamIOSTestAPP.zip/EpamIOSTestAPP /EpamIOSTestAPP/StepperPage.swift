//
//  NavigationBarPage.swift
//  EpamIOSTestAPP
//
//  Created by Roman Morozov2 on 16.11.2020.
//

import SwiftUI

struct StepperPage: View {
    @State private var stepperValue = 0
    @EnvironmentObject var viewRouter: ViewRouter
    var body: some View {
      
        HStack {
            Image(systemName: "heart.circle")
            Text("Cups of tea drank: \(stepperValue)")
            Spacer()
            Stepper("", value: $stepperValue)
                .frame(width: 100, height: 35)
                .offset(x: -4)
                .background(Color.blue)
                .cornerRadius(8)
        }
        .padding()
        
        Button(action: {
            withAnimation {
                viewRouter.currentPage = .MainPage
            }
        }) {
            BackButtonContent()
        }
    }

struct NavigationBarPage_Previews: PreviewProvider {
    static var previews: some View {
        StepperPage()
    }
}
}
