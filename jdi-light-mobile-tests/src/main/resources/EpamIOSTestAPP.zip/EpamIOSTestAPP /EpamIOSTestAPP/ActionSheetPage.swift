//
//  ActionSheetPage.swift
//  EpamIOSTestAPP
//
//  Created by Roman Morozov2 on 12.11.2020.
//

import SwiftUI

struct ActionSheetPage: View {
    
    @EnvironmentObject var viewRouter: ViewRouter
    @State private var showingSheet = false
    @State private var choose: String  = "-"
    
    var body: some View {
        VStack {
            Text("ActionSheet").padding(.top, 10 ).font(Font.largeTitle)
            Text("Selected value is:").padding(.all, 20)
            Text("\(choose)").padding(.all, 20).font(Font.largeTitle)
            Text(" ")
            Button(action: {
                       self.showingSheet = true
                   }) {
                       Text("Show Action Sheet").foregroundColor(.white)
                        .frame(width: 200, height: 50)
                        .background(Color.green)
                        .cornerRadius(15)
                        .padding(.top, 50)
                   }
                   .actionSheet(isPresented: $showingSheet) {
                    ActionSheet(title: Text("What do you want to do?"), message: Text("Choose one of three"), buttons: [
                                    .default(Text("one")){ choose = "one" },
                                    .default(Text("two")){ choose = "two" },
                                    .default(Text("three")){ choose = "three" },
                                    .cancel()])
                   }
                   Text(" ")
                   Text(" ")
                   Text(" ")
            Button(action: {
                withAnimation {
                    viewRouter.currentPage = .MainPage
                }
            }) {
                BackButtonContent()
            }
    }
    }
}

struct ActionSheetPage_Previews: PreviewProvider {
    static var previews: some View {
        ActionSheetPage()
    }
}
