//
//  ContentViewA.swift
//  EpamIOSTestAPP
//
//  Created by Roman Morozov2 on 12.11.2020.
//

import SwiftUI

struct MainPage: View {
    
        let elementType = ["DatePicker", "Slider", "ActionSheet", "ContextMenu", "ToggleSwitch", "AlertDialog", "TabView", "TextField", "SegmentedControl","Stepper"]
    
    @EnvironmentObject var viewRouter: ViewRouter
    
    var body: some View {
        VStack {
            Text("JDI Test App").padding(.top, 10 ).font(Font.largeTitle)
            NavigationView {
                          List(elementType, id: \.self) {
                            element in Button(action: {
                                    if element == "DatePicker" {
                                    withAnimation {
                                    viewRouter.currentPage = .DatePickerPage
                                    }
                                    }else if element == "Slider" {
                                        withAnimation {
                                        viewRouter.currentPage = .SliderPage
                                        }
                                    }
                                     else if element == "ActionSheet" {
                                        withAnimation {
                                        viewRouter.currentPage = .ActionSheetPage
                                        }
                                    }
                                     
                                     else if element == "ContextMenu" {
                                        withAnimation {
                                        viewRouter.currentPage = .ContextMenuPage
                                        }
                                    }
                                     
                                     else if element == "ToggleSwitch" {
                                        withAnimation {
                                        viewRouter.currentPage = .ToggleSwitchPage
                                        }
                                    }
                                     
                                     else if element == "AlertDialog" {
                                        withAnimation {
                                        viewRouter.currentPage = .AlertDialogPage
                                        }
                                    }
                                     else if element == "TabView" {
                                        withAnimation {
                                        viewRouter.currentPage = .TabViewPage
                                        }
                                    }
                                     else if element == "TextField" {
                                        withAnimation {
                                        viewRouter.currentPage = .TextFieldPage
                                        }
                                    }
                                     else if element == "SegmentedControl" {
                                        withAnimation {
                                        viewRouter.currentPage = .SegmentedControlPage
                                        }
                                    }
                                     else if element == "Stepper" {
                                        withAnimation {
                                        viewRouter.currentPage = .StepperPage
                                        }
                                    }
                                
                                     else {
                                        withAnimation {
                                        viewRouter.currentPage = .NotExistPage
                                        }
                                    }
                                
                                
                    
                                }){
                             NextButtonContent(element: element)
                            }
                      }
              }
        }
     }

}

struct ContentViewA_Previews: PreviewProvider {
    static var previews: some View {
        MainPage().environmentObject(ViewRouter())
    }
}



struct NextButtonContent : View {
    let element : String
    var body: some View {
        Text(element)
    }
}

struct NotExistButtonContent : View {
    var body: some View {
        Text("This page is not made")
        Text("Back to menu")
            .foregroundColor(.white)
            .frame(width: 200, height: 50)
            .background(Color.blue)
            .cornerRadius(15)
            .padding(.top, 50)
    }
}


