//
//  Helper.swift
//  EpamIOSTestAPP
//
//  Created by Roman Morozov2 on 12.11.2020.
//

import Foundation

enum Page {
    case MainPage
    case DatePickerPage
    case NotExistPage
    case SliderPage
    case ActionSheetPage
    case ContextMenuPage
    case ToggleSwitchPage
    case AlertDialogPage
    case TabViewPage
    case TextFieldPage
    case SegmentedControlPage
    case StepperPage
}
