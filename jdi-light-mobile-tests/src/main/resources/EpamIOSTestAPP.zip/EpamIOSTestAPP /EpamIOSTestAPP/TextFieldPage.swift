//
//  TextFieldPage.swift
//  EpamIOSTestAPP
//
//  Created by Roman Morozov2 on 16.11.2020.
//

import SwiftUI

struct TextFieldPage: View {
    @State private var username: String = ""
    @State private var submitName: String = "-"
    @EnvironmentObject var viewRouter: ViewRouter
    
    var body: some View {
        Text("")
        Text("Your name:").padding(.all, 20)
        Text(submitName).padding(.all, 20)
        Text("")

        HStack(alignment: .center) {
        
            Text("Username:")
                .font(.callout)
                .bold()
            TextField("Enter username...", text: $username)
                .textFieldStyle(RoundedBorderTextFieldStyle())
        }.padding(.all, 30)
     
        Button(action: {
            if username == "" {
                username = "-"
            }
            submitName = username
            username = ""
                }) {
            Text("Submit").foregroundColor(.white)
             .frame(width: 200, height: 50)
             .background(Color.green)
             .cornerRadius(15)
             .padding(.top, 50)
                }
        Text(" ")
        Text(" ")
        Button(action: {
             withAnimation {
                    viewRouter.currentPage = .MainPage
                           }
                           }) {
                    BackButtonContent()
                    }
    }
}

struct TextFieldPage_Previews: PreviewProvider {
    static var previews: some View {
        TextFieldPage()
    }
}
