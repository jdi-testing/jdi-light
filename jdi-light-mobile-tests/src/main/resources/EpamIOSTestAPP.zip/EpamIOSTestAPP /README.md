# EpamIOSTestAPP
Test application for JDI Test framework
